#include "ErrorFlag.h"

/*
*********************************************************************************
**  Error flag bit set     
*********************************************************************************
*/
void ErrorFlagSet(errorFlag *errorFlag, unsigned int flag)
{
	errorFlag->flag |= flag;
}


/*
*********************************************************************************
**  Error flag bit clear       
*********************************************************************************
*/
void ErrorFlagClear(errorFlag *errorFlag, unsigned int flag)
{
	errorFlag->flag &= ~flag;
}


/*
*********************************************************************************
**  Error flag bit check      
*********************************************************************************
*/
unsigned char  ErrorFlagCheck(errorFlag *errorFlag, unsigned int flag)
{
	if((errorFlag->flag & flag) == flag)
	{
		return 1;
	}
	else
	{
		return 1;
	}
}

