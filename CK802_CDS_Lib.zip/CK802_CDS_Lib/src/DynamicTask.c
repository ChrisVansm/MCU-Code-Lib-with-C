
#include "Functions.h"
#include "DynamicTask.h"

//=================================================================================================
//=================================================================================================

#define  MAX_DYNAMIC_TASK   16    //max allowed number of tasks
#define  MAX_TASK_QUEUE     8     //max allowed number of tasks in queue at one time

static uint8 dynamicTaskCount;
static uint8 dynamicTaskMap[MAX_DYNAMIC_TASK];
static uint32 DynamicTaskQueue[MAX_TASK_QUEUE];

//=================================================================================================
// Initialize for dynamic task queue
//
// Input:   none
// Return:  none
//=================================================================================================
void  InitDynamicTask(void)
{
   MemFill((uint8*)DynamicTaskQueue, 0, MAX_TASK_QUEUE*sizeof(uint32));			//fill with 0
   MemFill(dynamicTaskMap, 0xff, MAX_DYNAMIC_TASK);								//reset task mapping
   dynamicTaskCount = 0;                  //no task at this moment
}

//=================================================================================================
// Create a dynamic task. Can be called in ISR
//
// Input:   taskId - task serial ID, start from 0
//          taskEntry - task function entry, must be type of (void (*) (void))
// Return:  0x01 - create-task success
//          0xff - create-task failed
//          0x00 - tast already exists
//=================================================================================================
uint8  CreateDynamicTask(uint8 taskId, void *taskEntry)
{
   //uint32 intMaskState;

   if (taskId>(MAX_DYNAMIC_TASK-1)) return(0xff);        //task ID is out of range
   if (dynamicTaskMap[taskId]!=0xff) return(0x00);       //task already created
   if (dynamicTaskCount>(MAX_TASK_QUEUE-1)) return(0xff);//task queue is full
   
   //intMaskState = GetInterruptMaskBit();     //get current interrupt mask bit
   //DisableInterrupts;                      //disable global interrupt in anyway
   
   DynamicTaskQueue[dynamicTaskCount]   = (uint32)taskEntry;	//put the task entry into teh queue

   dynamicTaskMap[taskId] = dynamicTaskCount;            //update task mapping
   dynamicTaskCount++;
   
   //if (intMaskState==0) //interrupt is allowed currently
   //   EnableInterrupts; //re-enable global interrupt
   
   return(0x01);                                         //return with success
}

//=================================================================================================
// Kill a dynamic task. CAN NOT be called in ISR
//
// Input:   taskId - task serial ID, start from 0
// Return:  0x01 - kill-task success
//          0xff - kill-task failed
//=================================================================================================
uint8  KillDynamicTask(uint8 taskId)
{
   uint32 i, taskOffset, *srcPtr, *desPtr;
   
   if (taskId>(MAX_DYNAMIC_TASK-1)) return(0xff);        //task ID is out of range

   taskOffset = dynamicTaskMap[taskId];
   if (taskOffset==0xff) return(0xff);                   //task not exist
   
   //DisableInterrupts;

   dynamicTaskMap[taskId] = 0xff;                        //remove task mapping
   dynamicTaskCount--;                                   //task counter decrease by 1
   
   desPtr = &DynamicTaskQueue[taskOffset];				 //destination pointer
   srcPtr = desPtr + 1;                     			 //source pointer
   while (taskOffset<dynamicTaskCount) {                 //remove task code and compacting the queue
       *desPtr++ = *srcPtr++;
       taskOffset++;
       for (i=0;i<MAX_DYNAMIC_TASK;i++) {
         if (dynamicTaskMap[i]==taskOffset) {            //update task mapping
            dynamicTaskMap[i]--;
            break;
         }
       }
   }

   *desPtr = 0;		 //clear queue area

   //EnableInterrupts;
   
   return(0x01);              //return with success
}

//=================================================================================================
// Run dynamic task queue
//
// Input:   none
// Return:  none
//=================================================================================================
void  RunDynamicTask(void)
{
	uint32 i;
	
	if (!dynamicTaskCount) return;
	
	for (i=0; i<dynamicTaskCount; i++) {
		if (!DynamicTaskQueue[i]) return;
		((void(*)(void))DynamicTaskQueue[i])();
	}
}
