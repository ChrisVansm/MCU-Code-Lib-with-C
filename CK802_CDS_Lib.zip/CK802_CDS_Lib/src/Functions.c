
#include "Functions.h"

//==============================================================
// Global variables and functions which are declared in user code
//==============================================================
static uint32 msTimeoutCount=0;    	//counter of mili-seconds             

static const uint8 dayInEachMonth[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
                                     //  -   1   2   3   4   5   6   7   8   9  10  11  12

static uint32 secElapseCount=0,       //tracking of 1 second elapse
              secTimeoutCount=0;      //counter of seconds

//==============================================================
// Add up the counter in mili-seconds
//==============================================================
void MsCounterUpdate(uint32 delta)
{
   msTimeoutCount += delta;
}

//==============================================================
// Increment the counter in seconds
//==============================================================
void SecondCounterUpdate()
{
   if (TimeOutChkMsLong(&secElapseCount, 1000))
      secTimeoutCount++;
}

//==============================================================
// Check for long timeout occurance in mili-seconds (max 65535ms)
// Input *timer     - pointer of timer counter
//       timeOutVal - timeout value, 0=forced timer update
// Return 0    - no timeout yet
//        0xffffffffff - timeout occured and timer updated
//==============================================================
uint32 TimeOutChkMsLong(uint32 *timer, uint32 timeOutVal)
{
  uint32 shadow, diff;
  
  shadow = msTimeoutCount;
  
  if (timeOutVal==0) {
     *timer = shadow;
     return(0xffffffff);
  }
  else {
     diff = shadow - *timer;
     if (diff>=timeOutVal) {
        *timer += timeOutVal;
        return(0xffffffff);
     } else {
        return(0);
     }
  }
}

//==============================================================
// Set stopwatch in mili-second
// Input *timer     - pointer of timer counter
//==============================================================
void StopwatchMsSet(uint32 *timer)
{
  *timer = msTimeoutCount;
}

//==============================================================
// Get stopwatch elapse in mili-second from last setting
// Input  timer     - timer counter value
// Return time elapse in mili-second (0x00000000 - 0xffffffff)
//==============================================================
uint32 StopwatchMsElapse(uint32 timer)
{
  uint32 shadow;
  
  shadow = msTimeoutCount;
  
  return(shadow-timer);
}

//==============================================================
// Check for long timeout occurance in seconds (max 65535s)
// Input *timer     - pointer of timer counter
//       timeOutVal - timeout value, 0=forced timer update
// Return 0          - no timeout yet
//        0xffffffff - timeout occured and timer updated
//==============================================================
uint32 TimeOutChkSecLong(uint32 *timer, uint32 timeOutVal)
{
  uint32 diff;
  
  if (timeOutVal==0) {
     *timer = secTimeoutCount;
     return(0xffffffff);
  }
  else {
     diff = secTimeoutCount - *timer;
     if (diff>=timeOutVal) {
        *timer += timeOutVal;
        return(0xffffffff);
     } else {
        return(0);
     }
  }
}

//==============================================================
// Set stopwatch in second
// Input *timer     - pointer of timer counter
//==============================================================
void StopwatchSecSet(uint32 *timer)
{
  *timer = secTimeoutCount;
}

//==============================================================
// Get stopwatch elapse in second from last setting
// Input  timer     - timer counter value
// Return time elapse in second (0x0000 - 0xffffffff)
//==============================================================
uint32 StopwatchSecElapse(uint32 timer)
{
  return(secTimeoutCount-timer);
}

//==============================================================
// Calculate the checksum for a data stream
// Result is in original form
//==============================================================
uint8 CheckSumCalNorm(uint8* str, uint32 len)
{
   uint8 sum = 0;

   while(len--) sum += *str++;

   return(sum);
}

//==============================================================
// Calculate the checksum for a data stream
// Result is complemented
//==============================================================
uint8 CheckSumCalComp(uint8* str, uint32 len)
{
   uint8 sum = 0;

   while(len--) sum += *str++;

   return((uint8)(0-sum));
}

//==============================================================
// Fill memory with data provided
//==============================================================
void MemFill(uint8* mem, uint8 fillDat, uint32 len)
{
   while(len--) *mem++ = fillDat;
}

//==============================================================
// Memory block copy
//==============================================================
void MemCopy(uint8* src, uint8* des, uint32 len)
{
   while(len--) *des++ = *src++;
}

//==============================================================
// Memory block compare
// Return: 1 if str1 > str2
//         0 if str1 = str2
//        -1 if str1 < str2
//==============================================================
int32 MemComp(uint8* str1, uint8* str2, uint32 len)
{
   uint8 dat1, dat2;
   
   while(len--) {
      dat1 = *str1;
      dat2 = *str2;
      if (dat1>dat2) return(1);
      else if (dat1<dat2) return(-1);
      str1++;
      str2++;
   }
   
   return(0);
}

//==============================================================
// Get the length of string
// Return - number of bytes in string
//==============================================================
uint32 StrLen(uint8 *str)
{
   uint32 i=0;
   while(*str++) i++;
   return(i);
}

//==============================================================
// Append text str2 after str1
// Return - number of bytes in total
//==============================================================
uint32 StrCat(uint8* str1, uint8* str2)
{
   uint32 i,j,k;
   i = StrLen(str1);    //length of string1
   j = StrLen(str2);    //length of string2
   k = i+j;             //total length
   str1 += i;           //point to string1 end
   while(j--) *str1++ = *str2++;    //attach string2
   *str1 = 0;           //end of string
   return(k);
}

//==============================================================
// Copy text string n bytes
// [strS] - string source
// [strD] - string destination to be copied
// [n]    - count of bytes
// Return - number fo bytes actually copied
//==============================================================
uint32 StrCopyN(uint8 *strS, uint8 *strD, uint32 n)
{
   uint32 i=0;
   while(n) {
      if (*strS) {
         *strD++ = *strS++;
         n--;
         i++;
      }
      else
         break;
   }
   *strD = 0;
   return(i);
}

//==============================================================
// Convert a ASCII number srting to double float
//==============================================================
double Str2Float(uint8 *str)
{
   double val, p10;
   uint32 pos, len, dot, digi;
   
   val = 0.0;
   p10 = 1.0;
   len = StrLen(str);
   
   //search for decimal dot
   dot  = 0;
   digi = 0;
   pos = len;
   while(pos) {
      pos--;
      if (str[pos]=='.') {
         dot = digi;
         break;
      }
      digi++;
   }
   
   //convert the string
   while(len) {
      len--;
      digi = str[len];
      if (digi!='.') {
         digi -= '0';
         val += (double)digi * p10;
         p10 *= 10.0;
      }
   }
   
   //adjust value per decimal dot
   while(dot) {
      val /= 10.0;
      dot--;
   }
   
   return(val);
}

//==============================================================
// Convert a 0-99 binary byte to 2-bytes of decimal text 
// in ASCII form
//==============================================================
void Bin2DecText(uint8 bin, uint8 *ascBuff)
{
   if (bin>99) {
      *ascBuff++ = ' ';
      *ascBuff   = ' ';
   }
   else {
      *ascBuff++ = '0'+bin/10;
      *ascBuff   = '0'+bin%10;
   }
}

//==============================================================
// Convert a binary byte to 2-bytes of hex text in ASCII form
//==============================================================
void Bin2HexText(uint8 bin, uint8 *hexBuff)
{
   uint8 tmp;
   
   //convert high-nibble
   tmp = (uint8)(bin>>4);
   if (tmp<10) tmp += '0';
   else tmp = tmp-10+'A';
   *hexBuff++ = tmp;

   //convert low-nibble
   tmp = bin&0x0f;
   if (tmp<10) tmp += '0';
   else tmp = tmp-10+'A';
   *hexBuff = tmp;
}

//==============================================================
// Convert a binary byte to BCD format
//==============================================================
uint8 Bin2Bcd(uint8 bin)
{
	return(((bin/10)<<4)+(bin%10));
}

//==============================================================
// Convert a BCD coded byte to binary format
//==============================================================
uint8 Bcd2Bin(uint8 bcd)
{
	return(((bcd>>4)*10)+(bcd&0x0f));
}

//==============================================================
// Convert a 0-65535 word binary to BCD format
//
// Input:
//    bin      = an integer of binary data
//    *bcdBuff = buffer pointer to store BCD form
// Return:
//    None
//==============================================================
void Word2Bcd(uint16 bin, uint8* bcdBuff)
{
	uint32 d0Tmp;
	uint32 d4, d3, d2, d1, d0, q;
	
	d0 = bin&0x000f; bin >>=4;
	d1 = bin&0x000f; bin >>=4;
	d2 = bin&0x000f; bin >>=4;
	d3 = bin&0x000f;
	
	d0Tmp = 6*(d3 + d2 + d1) + d0;
	q = d0Tmp / 10;
	d0 = d0Tmp % 10;

	d1 = q + 9*d3 + 5*d2 + d1;
	q = d1 / 10;
	d1 = d1 % 10;

	d2 = q + 2*d2;
	q = d2 / 10;
	d2 = d2 % 10;
	
	d3 = q + 4*d3;
	q = d3 / 10;
	d3 = d3 % 10;
	
	d4 = q;
	
	bcdBuff[0] = d4;
	bcdBuff[1] = (d3<<4) + d2;
	bcdBuff[2] = (d1<<4) + d0;
}

//==============================================================
// Convert a 0-65535 BCD to binary word format
//
// Input:
//    *bcd = pointer of buffer containing BCD form
// Return:
//    integer data in binary form
//==============================================================
uint16 Bcd2Word(uint8 *bcd)
{
   uint16 result;

   result  = Bcd2Bin(*bcd++)*10000;
   result += Bcd2Bin(*bcd++)*100;
   result += Bcd2Bin(*bcd);

   return(result);
}

//=============================================================================
// Convert a long value to 3-bytes of BCD
//
// Input:
//    dat      = an long-type ofbinary data
//    *bcdBuff = buffer pointer to store BCD form
// Return:
//    None
//=============================================================================
void Long2Bcd3(uint32 dat, uint8 *bcdBuff)
{
	uint8 hiPos;
	uint16 tmp;
	
	if (dat>=999999) {
		bcdBuff[0] = 0x99;
		bcdBuff[1] = 0x99;
		bcdBuff[2] = 0x99;
		return;
	}
	
	hiPos = (uint8)(dat/10000);
	tmp   = (uint32)(dat - hiPos*10000);
	Word2Bcd(tmp, bcdBuff);
	bcdBuff[0] = Bin2Bcd(hiPos);
}

//==============================================================
// Increment a 4 byte BCD number by 1
// BCD numbers are stored in big-endian format
// For example: bcd=0x11223399, after function call
//              bcd=0x11223400
//
// Input:
//    *bcd = pointer of buffer containing BCD form.
// Return:
//    Value updated
//==============================================================
void Bcd4BytesInc(uint8 *bcd)
{
}

//==============================================================
// Add up two 4-byte BCD numbers: bcd1 = bcd1 + bcd2
// BCD numbers are stored in big-endian format
// For example: bcd1=0x11223344, bcd2=0x55667788, after function call
//              bcd1=0x66891132
//
// Input:
//    *bcd1 & *bcd2 = pointer of buffer containing BCD form.
// Return:
//    Sum stored in the place of bcd1
//==============================================================
void Bcd4BytesAdd(uint8 *bcd1, uint8 *bcd2)
{
}

//==============================================================
// Add up two 3-byte BCD numbers: bcd1 = bcd1 + bcd2
// BCD numbers are stored in big-endian format
// For example: bcd1=0x112233, bcd2=0x445566, after function call
//              bcd1=0x337799
//
// Input:
//    *bcd1 & *bcd2 = pointer of buffer containing BCD form.
// Return:
//    Sum stored in the place of bcd1
//==============================================================
void Bcd3BytesAdd(uint8 *bcd1, uint8 *bcd2)
{
}

//==============================================================
// Decrement a 4 byte BCD number by 1
// BCD numbers are stored in big-endian format
// For example: bcd=0x11223300, after function call
//              bcd=0x11223299
//
// Input:
//    *bcd = pointer of buffer containing BCD form.
// Return:
//    Value updated
//==============================================================
void Bcd4BytesDec(uint8 *bcd)
{
}

//==============================================================
// Reverse the order of 4-byte BCD number
// For example: 0x11223344 ->0x44332211
//
// Input:
//    *bcd = pointer of buffer containing BCD form.
//
// Return:
//    Order reversed
//==============================================================
void Bcd4BytesReverse(uint8 *bcd)
{
}

//==============================================================
// Validate for a string of same data byte with given length
// Return true if match, otherwise return false
//==============================================================
BOOL CharStringValidate(uint8 *ptr, uint8 charDat, uint32 length)
{
	while(length--) {
		if (*ptr++ != charDat) return(FALSE);
	}
	
	return(TRUE);
}

//====================================================================
// Reverse order for a string of data bytes
// Data source - [source], data destination - [dest], size - [len]
//====================================================================
void StringReverse(uint8 *source, uint8 *dest, uint32 len)
{
	uint32 i, sPtr, dPtr;

	if (len==0) return;

	sPtr = len-1;
	dPtr = 0;

	for (i=0;i<len;i++) {
		dest[dPtr++] = source[sPtr--];
	}
}


//====================================================================
// Get number of days in a given year/month
//====================================================================
uint8 GetDayInMonth(uint16 year, uint8 mon)
{
	if (mon>12) return(0);
	else if (mon==2) {
		if ((year&0x03) == 0) return(29); //Feb in leap year
		else return(28);
	} else return(dayInEachMonth[mon]);
}

//====================================================================
// Get a previous day base on given year, month & day
//====================================================================
uint8 GetPreviousDay(uint16 year, uint8 mon, uint8 day)
{
	if (day>1) return(day-1);

	else {	//now is day 1
		mon--;
		if (mon==0)			//should be Dec. 
			return(31);	
		else {
			if (mon==2) {	//conside Feb
				if (year%4 == 0) return(29);
				else return(28);
			}
			else return(dayInEachMonth[mon]);
		}
	}
}

//====================================================================
// Get a next day base on given year, month & day
//====================================================================
uint8 GetNextDay(uint16 year, uint8 mon, uint8 day)
{
	uint8 maxDay;
	
	if (mon==2) {
	   if ((year&0x03) == 0) maxDay=29;
	   else maxDay=28;
   } else
      maxDay = dayInEachMonth[mon];
      
	if (day==maxDay) {   //now is the last day in month
	   return(1);        //next day is day 1
	}
	else return(day+1);
}

//==============================================================================
// Move a date backward or forward
// max moving range -128 - +127
//==============================================================================
void MoveDate(uint16 *year, uint8 *mon, uint8 *day, int16 delta)
{
	uint16 tmpYear = *year;
	uint8 tmpMon  = *mon;
	uint8 tmpDay  = *day;
	
	while(delta) {
		if ((delta>0) == 0) {
			delta--;
			tmpDay++;
			if (tmpDay>GetDayInMonth(tmpYear, tmpMon)) {
				tmpDay = 1;
				tmpMon++;
				if (tmpMon>12) {
					tmpMon = 1;
					tmpYear++;
				}
			}
		} else {
			delta++;
			tmpDay--;
			if (tmpDay==0) {
				tmpMon--;
				if (tmpMon==0) {
					tmpMon = 12;
					tmpYear--;
				}
				tmpDay = GetDayInMonth(tmpYear, tmpMon);
			}
		}
	}

	*year = tmpYear;
	*mon  = tmpMon;
	*day  = tmpDay;
}

//=================================================================================================
// Get current interrupt mask bit
// Return: !0, if interrupt is disabled
//         0,  if interrupt is enabled
//=================================================================================================
uint32 GetInterruptMask(void)
{
	register int maskInfo asm("a3");

	__asm("mfcr a3, psr");
	__asm("lrw  a2, 0x00000040");	//ie @ bit-6
	__asm("and  a3, a2");
	__asm("xor  a3, a2");

	return(maskInfo);
}

//=================================================================================================
// Enable all interrupt & return original interrupt enable/disable setting
// Return:  0, interrupt enabled
//=================================================================================================
uint32 EnableInterrupt(void)
{
	__asm("psrset ee,ie");
	return(0);
}

//=================================================================================================
// Disable all interrupt & return original interrupt enable/disable setting
// Return: !0, interrupt disabled
//=================================================================================================
uint32 DisableInterrupt(void)
{
	__asm("psrclr ee,ie");
	return(0x00000040);	//ie bit-field value
}

//=================================================================================================
// Restore interrupt
// In:   intDis!=0, disable interrupt;  intDis==0, enable interrupt
// Return:
//       No
//=================================================================================================
void RestoreInterrupt(uint32 intDis)
{
	if (intDis)
		__asm("psrclr ee,ie");	//disable interrupt
	else
		__asm("psrset ee,ie");	//enable interrupt
}

//==============================================================================
// Force MCU to Reset by setting CK802 core special register
//==============================================================================
void ForceReset(void)
{
	__asm("lrw32 a0, 0xABCD0000");	//set 0xABCD for high 16-bit
	__asm("mtcr a0, cr<31,0>");		//write into special control register to generate a reset

	//wait for reset to occur
	while(1); 
}


//==============================================================================
// Get the high byte from a 16-bit integer
//==============================================================================
uint8 Int16_GetByte1(uint16 i)
{
   return((uint8)(i>>8));
}

//==============================================================================
// Get the low byte from a 16-bit integer
//==============================================================================
uint8 Int16_GetByte0(uint16 i)
{
   return((uint8)i);
}

//==============================================================================
// Get the Most-significant byte from a 32-bit integer
//==============================================================================
uint8 Int32_GetByte3(uint32 x)
{
   return((uint8)(x>>24));
}

//==============================================================================
// Get the 2nd-significant byte from a 32-bit integer
//==============================================================================
uint8 Int32_GetByte2(uint32 x)
{
   return((uint8)(x>>16));
}

//==============================================================================
// Get the 3rd-significant byte from a 32-bit integer
//==============================================================================
uint8 Int32_GetByte1(uint32 x)
{
   return((uint8)(x>>8));
}

//==============================================================================
// Get the Least-significant byte from a 32-bit integer
//==============================================================================
uint8 Int32_GetByte0(uint32 x)
{
   return((uint8)x);
}

//==============================================================================
// Get the high word from a 32-bit integer
//==============================================================================
uint16 Int32_GetWord1(uint32 x)
{
   return((uint16)(x>>16));
}

//==============================================================================
// Get the low word from a 32-bit integer
//==============================================================================
uint16 Int32_GetWord0(uint32 x)
{
   return((uint16)(x));
}

//==============================================================================
// Reverse the bit order for a byte
//==============================================================================
uint8 ByteBitReverse(uint8 x)
{
	uint32 i;
	uint8 tmp=0;
	for (i=0;i<8;i++) {
		tmp >>= 1;
		if (x&0x80)
			tmp |= 0x80;
		x <<= 1;
	}
	return(tmp);
}

//==============================================================================
// Reverse the bit order for a word
//==============================================================================
uint16 WordBitReverse(uint16 x)
{
	uint32 i;
	uint16 tmp=0;
	for (i=0;i<16;i++) {
		tmp >>= 1;
		if (x&0x8000)
			tmp |= 0x8000;
		x <<= 1;
	}
	return(tmp);
}


//==============================================================================
// Merge 2 8-bit bytes become 1 16-bit word
//==============================================================================
uint16 Merge2Bytes(uint8 hiByte, uint8 loByte)
{
   uint16 i = hiByte;
   i <<= 8;
   return(i+loByte);
}

//===========================================================================
// ��16λ����������ƽ����
// ������ֵ��Χ: 0x0000 - 0xFF00
//
// ����8λ������
//===========================================================================
uint8 SqrtUint16(uint16 dat)
{
	uint8 a, b, p; 
	uint16 K, A, B, C, R; 

	a = 0;
	b = 0;
	C = 0;
	A = 0;
	p = 0x80;
	R = 0x4000;

	do { 
		b = a - p;
		B = C;
		B >>= 1; 
		if (A) {
			K = A;
			K >>= 1;
		} 
		else {
			K = 0x8000; 
		}
		B += K;
		B -= R;
		if (dat > B)
			C = B; 
		else{
			A = B;
			a = b;
		} 
		p >>= 1;
		R >>= 2; 
	} while(p!=1);     //ѭ��7�ν��� 
	
	p  = (uint8)((A-C)>>2);
	A -= p;
	C += p; 
	b  = a; 
	
	if(dat < A) {
		b--;
	}
	if(dat < C) {
		b--;
	}

	return(b);
}

//===========================================================================
// ��32λ����������ƽ����
// ������ֵ��Χ: 0x00000000 - 0xFFFF0000
//
// ����16λ������
//===========================================================================
uint16 SqrtUint32(uint32 dat)
{
	uint16 a, b, p; 
	uint32 K, A, B, C, R; 

	if (dat <= 0xff00) {
		return(SqrtUint16((uint16)dat));
	}
	
	a = 0;
	b = 0;
	C = 0;
	A = 0;
	p = 0x8000;
	R = 0x40000000;

	do { 
		b = (a - p);
		B = C;
		B >>= 1; 
		if (A) {
			K = A;
			K >>= 1;
		} 
		else {
			K = 0x80000000;
		}
		B += K;
		B -= R;
		if (dat > B) {
			C = B; 
		}
		else {
			A = B;
			a = b;
		} 
		p >>= 1;
		R >>= 2; 
	} while(p!=1);     //ѭ��15�ν��� 
	
	p  = (uint16)((A-C)>>2);
	A -= p;
	C += p; 
	b  = a; 
	
	if(dat < A) {
		b--;
	}
	if(dat < C) {
		b--;
	}

	return(b);
}

//=============================================================================
// Start to assemble the outgoing packet
//=============================================================================
void OutPacket_Start(COMM_TXRX_PKT *pktInfo)
{
   pktInfo->pktTxBuff[0]	= pktInfo->pktEof;
	pktInfo->pktTxChksum	= 0;
	pktInfo->pktTxPtr		= 0;
	pktInfo->pktTxLen		= 1;
}

//=============================================================================
// End of outgoing packet assembling
//=============================================================================
void OutPacket_End(COMM_TXRX_PKT *pktInfo, void(*txEn)(void))
{
   OutPacket_Append(pktInfo, 0 - pktInfo->pktTxChksum); 		   //attach the checksum
   pktInfo->pktTxBuff[pktInfo->pktTxLen++] = pktInfo->pktEof;	//End-of-packet
   
   if (txEn) {		//enable transmit
		txEn();
	}
}

//=============================================================================
// Append a byte to the outgoing packet
//=============================================================================
void OutPacket_Append(COMM_TXRX_PKT *pktInfo, uint8 datOut)
{
   pktInfo->pktTxChksum += datOut;
   
   if (datOut == pktInfo->pktEof) {
   	pktInfo->pktTxBuff[pktInfo->pktTxLen++] = pktInfo->pktSub;
   	pktInfo->pktTxBuff[pktInfo->pktTxLen++] = pktInfo->pktSd1;
   }
   else
   if (datOut == pktInfo->pktSub) {
   	pktInfo->pktTxBuff[pktInfo->pktTxLen++] = pktInfo->pktSub;
   	pktInfo->pktTxBuff[pktInfo->pktTxLen++] = pktInfo->pktSd2;
   }
   else {
   	pktInfo->pktTxBuff[pktInfo->pktTxLen++] = datOut;
   }
}

//=============================================================================
// Append a string to outgoing packet
//=============================================================================
void OutPacket_String(COMM_TXRX_PKT *pktInfo, uint8 *str, uint8 count)
{
	while(count) {
   	OutPacket_Append(pktInfo, *str++);
   	count--;
   }
}

//=============================================================================
// Fill a string to outgoing packet
//=============================================================================
void OutPacket_Fill(COMM_TXRX_PKT *pktInfo, uint8 dat, uint8 count)
{
	while(count) {
   	OutPacket_Append(pktInfo, dat);
   	count--;
   }
}

//=============================================================================
// Reset for receiving packet
//=============================================================================
void InPacket_Reset(COMM_TXRX_PKT *pktInfo)
{
   pktInfo->pktRxLen    = 0;
   pktInfo->pktRxChksum = 0;
   pktInfo->pktRxErr    = 0;
   pktInfo->pktRxSub    = 0;
}

//=============================================================================
// Append data into RX packet
//=============================================================================
void InPacket_Append(COMM_TXRX_PKT *pktInfo, uint8 dat)
{
   if (pktInfo->pktRxLen >= pktInfo->pktRxMax) {
      pktInfo->pktRxErr = TRUE;
      return;
   }
   
	if (dat == pktInfo->pktSub) {
		pktInfo->pktRxSub = TRUE;
	}
	else {
		if (pktInfo->pktRxSub == TRUE) {
			if (dat == pktInfo->pktSd1) {
				dat = pktInfo->pktEof;
			}
			else
			if (dat == pktInfo->pktSd2) {
				dat = pktInfo->pktSub;
			}
			else {
		      pktInfo->pktRxErr = TRUE;
			}
		   pktInfo->pktRxSub = FALSE;
		}
		pktInfo->pktRxBuff[pktInfo->pktRxLen++] = dat;
		pktInfo->pktRxChksum += dat;
	}
   
}

//=============================================================================
// Check if RX packet is corrupted
//=============================================================================
BOOL InPacket_IsError(COMM_TXRX_PKT *pktInfo)
{
   if (pktInfo->pktRxChksum == 0 &&  pktInfo->pktRxErr==0)  //no error
      return(FALSE);
   else  //packet error
      return(TRUE);
}
