#include "malloc.h"

static tagMemAllocBlock *memBlkChain;
static void (*ErrorCallback)(void);

//=================================================================================================
//=================================================================================================
void HeapInit(uint8 *heapBuff, uint32 heapSize, void (*callback)(void))
{
	uint32 sizeAdj;
	
   sizeAdj = ((uint32)heapBuff) & 0x03;
   
   heapBuff += 3;
   heapBuff  = (uint8*)((uint32)heapBuff & 0xfffffffc);
   
	heapSize -= ((4-sizeAdj)&0x03);
   
   if (heapSize < (sizeof(tagMemAllocBlock)+4*sizeof(uint32))) {   //no heap available
      memBlkChain = (tagMemAllocBlock*)NULL;
      return;
   }

   heapSize -= sizeof(tagMemAllocBlock);  //size of heap available
   
   memBlkChain             = (tagMemAllocBlock*)heapBuff;
   memBlkChain->vacantTag  = 0x55aa55aa;   					//block is vacant
   memBlkChain->prevBlk    = (tagMemAllocBlock*)NULL;		//end of chain upwards
   memBlkChain->nextBlk    = (tagMemAllocBlock*)NULL;		//end of chain downwards
   memBlkChain->memNetSize = heapSize; 
   
   if (callback) ErrorCallback = callback;
   else ErrorCallback = NULL;
}

//=================================================================================================
//=================================================================================================
void* HeapMalloc(uint32 memSize)
{
   tagMemAllocBlock *memBlk, *newBlk;
   uint8 *memAddr;
   
   memSize += 3;
   memSize &= 0xfffc;		//memory block size aligns to 4
   
   memBlk = memBlkChain;   //set the entry of chain
   
   while(memBlk != (tagMemAllocBlock*)NULL) {
      if (memBlk->vacantTag==0x55aa55aa &&       //found vavant memory block with tag=0x55aa55aa
          memBlk->memNetSize >= memSize) {   	//and size is sufficient
         memBlk->vacantTag  = 0xaa55aa55;  		//block is occupied
         //grow the chain for new block allocation
         if (memBlk->memNetSize > (memSize+sizeof(tagMemAllocBlock))) {
            //grow new block
            newBlk = (tagMemAllocBlock*)((uint8*)memBlk + sizeof(tagMemAllocBlock) + memSize);
            newBlk->prevBlk    = memBlk;           //hookup the chain upwards
            newBlk->nextBlk    = memBlk->nextBlk;  //hookup the chain downwards
            newBlk->vacantTag  = 0x55aa55aa;
            newBlk->memNetSize = memBlk->memNetSize - memSize - sizeof(tagMemAllocBlock);
            //update the target block info
            memBlk->memNetSize = memSize;          //memory size allocated
            memBlk->nextBlk    = newBlk;           //hookup the chain downwards
         }
         memAddr = (uint8*)memBlk + sizeof(tagMemAllocBlock);
         return((void*)memAddr);
      }

      memBlk = memBlk->nextBlk;  //check for next block
   }
   
   //memory allocation failed
   if (ErrorCallback) ErrorCallback();
   
   return(NULL);  
}

//=================================================================================================
//=================================================================================================
BOOL HeapFree(void* targetMemPtr)
{
   tagMemAllocBlock *memBlk, *neighbor;
	   
   memBlk = memBlkChain;   //set the entry of chain

   while(memBlk!=NULL) {
      if (((uint8*)memBlk+sizeof(tagMemAllocBlock)) == (uint8*)targetMemPtr) { //block matched and to be freed
         memBlk->vacantTag = 0x55aa55aa;   //set as vacant
         //merge with next vacant block if there is
         neighbor = memBlk->nextBlk;
         if (neighbor!=NULL && neighbor->vacantTag==0x55aa55aa) {
            memBlk->memNetSize += neighbor->memNetSize + sizeof(tagMemAllocBlock);
            memBlk->nextBlk = neighbor->nextBlk;
            neighbor = neighbor->nextBlk;
            if (neighbor!=NULL) {
               neighbor->prevBlk = memBlk;
            }
         }
         //merge with previous vacant block if there is
         neighbor = memBlk->prevBlk;
         if (neighbor!=NULL && neighbor->vacantTag==0x55aa55aa) {
            neighbor->memNetSize += memBlk->memNetSize + sizeof(tagMemAllocBlock);
            neighbor->nextBlk = memBlk->nextBlk;
            memBlk = memBlk->nextBlk;
            if (memBlk!=NULL) {
               memBlk->prevBlk = neighbor;
            }
         }
         return(TRUE);
      }
      
      memBlk = memBlk->nextBlk;  //search for target memory block throughout the chain
   }
   
   //memory release failed
   if (ErrorCallback) ErrorCallback();
   
   return(FALSE);
}
