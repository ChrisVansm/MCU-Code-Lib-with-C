#ifndef __DYNAMICTASK_IMPLEMENTATION_2013_12_01_ZHANG_MING_FENG__
#define __DYNAMICTASK_IMPLEMENTATION_2013_12_01_ZHANG_MING_FENG__

//==============================================================
// file: DynamicTask.h
//==============================================================

#include "DataType.h"

void  InitDynamicTask(void);
uint8  CreateDynamicTask(uint8 taskId, void *taskEntry);
uint8  KillDynamicTask(uint8 taskId);
void  RunDynamicTask(void);


#endif
