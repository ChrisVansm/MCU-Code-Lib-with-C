#ifndef	__TYPE_DEFINITION__
#define	__TYPE_DEFINITION__

#ifndef	uint8
#define	uint8		unsigned char
#endif
#ifndef	uint16
#define	uint16	unsigned short
#endif
#ifndef	uint32
#define	uint32	unsigned	int
#endif

#ifndef	int8
#define	int8		signed char
#endif
#ifndef	int16
#define	int16		signed short
#endif
#ifndef	int32
#define	int32		signed int
#endif

#ifndef	vuint8
#define	vuint8	volatile unsigned char
#endif
#ifndef	vuint16
#define	vuint16	volatile unsigned short
#endif
#ifndef	vuint32
#define	vuint32	volatile unsigned	int
#endif

#ifndef	vint8
#define	vint8		volatile signed char
#endif
#ifndef	vint16
#define	vint16	volatile signed short
#endif
#ifndef	vint32
#define	vint32	volatile signed int
#endif

#ifndef	BOOL
#define	BOOL		uint32
#endif

#ifndef	NULL
#define	NULL		0
#endif

#ifndef	TRUE
#define	TRUE		1
#endif

#ifndef	FALSE
#define	FALSE		0
#endif

#endif
