#ifndef __MALLOC_IMPLEMENTATION_2013_12_01_ZHANG_MING_FENG__
#define __MALLOC_IMPLEMENTATION_2013_12_01_ZHANG_MING_FENG__

//==============================================================
// file: malloc.h
//==============================================================

#include "DataType.h"

typedef struct __tagMemAllocBlock {
   uint32 vacantTag;
   uint32 memNetSize;
   struct __tagMemAllocBlock *prevBlk;
   struct __tagMemAllocBlock *nextBlk;
} tagMemAllocBlock;

void  HeapInit(uint8 *heapBuff, uint32 heapSize, void (*callback)(void));
void* HeapMalloc(uint32 memSize);
BOOL  HeapFree(void *targetMemPtr);


#endif
