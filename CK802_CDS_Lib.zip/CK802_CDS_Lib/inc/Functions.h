//==============================================================
// File name : Functions.h
//==============================================================

#ifndef  _FUNCTIONS_LIB_2013_12_01_ZHANG_MING_FENG_
#define  _FUNCTIONS_LIB_2013_12_01_ZHANG_MING_FENG_

#include "DataType.h"

#define  BOOL     					uint32
#define  TRUE     					1
#define  FALSE    					0

#define	PORT_PIN_INPUT				0		//setting for port pin as input
#define	PORT_PIN_OUTPUT			1		//setting for port pin as output

//TPM channel control macro code, using '&' for combination
#define	CH_INT_EN					0b01111100		//TPM channel interrupt enable
#define	CH_INT_DIS					0b00111100		//TPM channel interrupt disable
#define	CH_CAPTURE					0b01001100		//TPM channel works in input capture mode
#define	CH_RISING_EDGE				0b01110100		//TPM channel capture rising edge only
#define	CH_FALLING_EDGE			0b01111000		//TPM channel capture falling edge only
#define	CH_BOTH_EDGE				0b01111100		//TPM channel capture both edges
#define	CH_COMPARE					0b01011100		//TPM channel works in output compare mode
#define	CH_TOGGLE					0b01110100		//TPM channel output toggle upon compare match
#define	CH_CLEAR						0b01111000		//TPM channel output cleared upon compare match
#define	CH_SET						0b01111100		//TPM channel output set compare match
#define	CH_GPIO						0b01110000		//TPM channel no forced output compare match (remain as GPIO)
#define	CH_PWM						0b01101100		//TPM channel works in PWM mode
#define	CH_PWM_HIGH_TRUE			0b01111000		//TPM channel PWM is high-true
#define	CH_PWM_LOW_TRUE			0b01110100		//TPM channel PWM is low-true

#define NOP()           __asm("nop")

//==============================================================
// Add up the counter in mili-seconds
//==============================================================
void MsCounterUpdate(uint32 delta);

//==============================================================
// Increment the counter in seconds
//==============================================================
void SecondCounterUpdate(void);

//==============================================================
// Check for long timeout occurance in mili-seconds (max 65535ms)
// Input *timer     - pointer of timer counter
//       timeOutVal - timeout value, 0=forced timer update
// Return 0    - no timeout yet
//        0xffffffff - timeout occured and timer updated
//==============================================================
uint32 TimeOutChkMsLong(uint32 *timer, uint32 timeOutVal);

//==============================================================
// Set stopwatch in mili-second
// Input *timer     - pointer of timer counter
//==============================================================
void StopwatchMsSet(uint32 *timer);

//==============================================================
// Get stopwatch elapse in mili-second from last setting
// Input  timer     - timer counter value
// Return time elapse in mili-second (0x00000000 - 0xffffffff)
//==============================================================
uint32 StopwatchMsElapse(uint32 timer);

//==============================================================
// Check for long timeout occurance in seconds (max 65535s)
// Input *timer     - pointer of timer counter
//       timeOutVal - timeout value, 0=forced timer update
// Return 0    - no timeout yet
//        0xffffffff - timeout occured and timer updated
//==============================================================
uint32 TimeOutChkSecLong(uint32 *timer, uint32 timeOutVal);

//==============================================================
// Set stopwatch in second
// Input *timer     - pointer of timer counter
//==============================================================
void StopwatchSecSet(uint32 *timer);

//==============================================================
// Get stopwatch elapse in second from last setting
// Input  timer     - timer counter value
// Return time elapse in second (0-65535)
//==============================================================
uint32 StopwatchSecElapse(uint32 timer);

//==============================================================
// Calculate the checksum for a data stream
// Result is in original form
// Input: [*str] - pointer to the string of data
//        [len]  - no. of bytes for checksum  calculation
// return: Sum of all data bytes
//==============================================================
uint8 CheckSumCalNorm(uint8* str, uint32 len);

//==============================================================
// Calculate the checksum for a data stream
// Result is complemented
// Input: [*str] - pointer to the string of data
//        [len]  - no. of bytes for checksum  calculation
// return: complemented sum of all data bytes
//==============================================================
uint8 CheckSumCalComp(uint8* str, uint32 len);

//==============================================================
// Fill memory with data provided
// Input: [*mem] - data memory address pointer
//        [*des] - data to be filled in
//        [len]  - no. of byte spaces to be filled
//==============================================================
void MemFill(uint8* mem, uint8 fillDat, uint32 len);

//==============================================================
// Memory block copy
// Input: [*src] - data source pointer
//        [*des] - data destination pointer
//        [len]  - no. of bytes to be copied
//==============================================================
void MemCopy(uint8* src, uint8* des, uint32 len);

//==============================================================
// Memory block compare
// Input: [*str1] - pointer to data strign 1
//        [*str2] - pointer to data strign 2
//        [len]   - no. of bytes to be compared
// Return: 1 if str1 > str2
//         0 if str1 = str2
//        -1 if str1 < str2
//==============================================================
int32 MemComp(uint8* str1, uint8* str2, uint32 len);

//==============================================================
// Get the length of string
// Return - number of bytes in string
//==============================================================
uint32 StrLen(uint8 *str);

//==============================================================
// Append str2 after str1
// Return - number of bytes in total
//==============================================================
uint32 StrCat(uint8* str1, uint8* str2);

//==============================================================
// Copy text string n bytes
// [strS] - string source
// [strD] - string destination to be copied
// [n]    - count of bytes
// Return - number fo bytes actually copied
//==============================================================
uint32 StrCopyN(uint8 *strS, uint8 *strD, uint32 n);

//==============================================================
// Convert a ASCII number srting to double float
//==============================================================
double Str2Float(uint8 *str);

//==============================================================
// Convert a 0-99 binary byte to 2-bytes of decimal text 
// in ASCII form
//==============================================================
void Bin2DecText(uint8 bin, uint8 *ascBuff);

//==============================================================
// Convert a binary byte to 2-bytes of hex text in ASCII form
//==============================================================
void Bin2HexText(uint8 bin, uint8 *hexBuff);

//==============================================================
// Convert a binary byte to BCD format
//==============================================================
uint8 Bin2Bcd(uint8 bin);

//==============================================================
// Convert a BCD coded byte to binary format
//==============================================================
uint8 Bcd2Bin(uint8 bcd);

//==============================================================
// Convert a 0-65535 word binary to BCD format
//==============================================================
void Word2Bcd(uint16 bin, uint8* bcdBuff);

//==============================================================
// Convert a 0-65535 BCD to binary word format
//==============================================================
uint16 Bcd2Word(uint8 *bcd);

//==============================================================
// Convert a long value to 3-bytes of BCD
//==============================================================
void Long2Bcd3(uint32 dat, uint8 *bcd);

//==============================================================
// decrement a 4 byte BCD number by 1
//==============================================================
void Bcd4BytesDec(uint8 *bcd);

//==============================================================
// Increment a 4 byte BCD number by 1
//==============================================================
void Bcd4BytesInc(uint8 *bcd);

//==============================================================
// Add up two 4-byte BCD numbers: bcd1 = bcd1 + bcd2
//==============================================================
void Bcd4BytesAdd(uint8 *bcd1, uint8 *bcd2);

//==============================================================
// Add up two 3-byte BCD numbers: bcd1 = bcd1 + bcd2
//==============================================================
void Bcd3BytesAdd(uint8 *bcd1, uint8 *bcd2);

//==============================================================
// Reverse the order of 4-byte BCD number
//==============================================================
void Bcd4BytesReverse(uint8 *bcd);

//==============================================================
// Validate for a string of same data byte with given length
// Return true if match, otherwise return false
//==============================================================
BOOL CharStringValidate(uint8 *ptr, uint8 charDat, uint32 length);

//====================================================================
// Reverse order for a string of data bytes
// Data source - [source], data destination - [dest], size - [len]
//====================================================================
void StringReverse(uint8 *source, uint8 *dest, uint32 len);

//====================================================================
// Get number of days in a given year/month
//====================================================================
uint8 GetDayInMonth(uint16 year, uint8 mon);

//====================================================================
// Get a previous day base on given year, month & day
//====================================================================
uint8 GetPreviousDay(uint16 year, uint8 mon, uint8 day);

//====================================================================
// Get a next day base on given year, month & day
//====================================================================
uint8 GetNextDay(uint16 year, uint8 mon, uint8 day);

//==============================================================================
// Move a date backward or forward
// max moving range -128 - +127
//==============================================================================
void MoveDate(uint16 *year, uint8 *mon, uint8* day, int16 delta);

//=================================================================================================
// Get current interrupt mask bit in CCR
// Return: 1, if PRIMASK=1
//         0, if PRIMASK=0
//=================================================================================================
uint32 GetInterruptMask(void);

//=================================================================================================
// Disable all interrupt & return original interrupt enable/disable setting
// Return: !0, if PRIMASK=1
//          0, if PRIMASK=0
//=================================================================================================
uint32 DisableInterrupt(void);

//=================================================================================================
// Enable all interrupt & return original interrupt enable/disable setting
// Return: !0, if PRIMASK=1
//          0, if PRIMASK=0
//=================================================================================================
uint32 EnableInterrupt(void);

//=================================================================================================
// Restore interrupt
// In:   intDis!=0, disable interrupt;  intDis==0, enable interrupt
// Return:
//       No
//=================================================================================================
void RestoreInterrupt(uint32 intDis);

//==============================================================================
// Force MCU to Reset by executing an illegal instruction
//==============================================================================
void ForceReset(void);

//==============================================================================
// Get the high byte from a 16-bit integer
//==============================================================================
uint8 Int16_GetByte1(uint16 i);

//==============================================================================
// Get the low byte from a 16-bit integer
//==============================================================================
uint8 Int16_GetByte0(uint16 i);

//==============================================================================
// Get the Most-significant byte from a 32-bit integer
//==============================================================================
uint8 Int32_GetByte3(uint32 x);

//==============================================================================
// Get the 2nd-significant byte from a 32-bit integer
//==============================================================================
uint8 Int32_GetByte2(uint32 x);

//==============================================================================
// Get the 3rd-significant byte from a 32-bit integer
//==============================================================================
uint8 Int32_GetByte1(uint32 x);

//==============================================================================
// Get the Least-significant byte from a 32-bit integer
//==============================================================================
uint8 Int32_GetByte0(uint32 x);

//==============================================================================
// Get the high word from a 32-bit integer
//==============================================================================
uint16 Int32_GetWord1(uint32 x);

//==============================================================================
// Get the low word from a 32-bit integer
//==============================================================================
uint16 Int32_GetWord0(uint32 x);

//==============================================================================
// Reverse 8 bits order in a byte
//==============================================================================
uint8 ByteBitReverse(uint8 x);

//==============================================================================
// Reverse 16 bits order in a word
//==============================================================================
uint16 WordBitReverse(uint16 x);

//==============================================================================
// Merge two 8-bit bytes and turn to one 16-bit word
//==============================================================================
uint16 Merge2Bytes(uint8 hiByte, uint8 loByte);

//===========================================================================
// ��16λ����������ƽ����
// ������ֵ��Χ: 0x0000 - 0xFF00
//
// ����8λ������
//===========================================================================
uint8 SqrtUint16(uint16 dat);

//===========================================================================
// ��32λ����������ƽ����
// ������ֵ��Χ: 0x00000000 - 0xFFFF0000
//
// ����16λ������
//===========================================================================
uint16 SqrtUint32(uint32 dat);

//==============================================================================
// Heap memory allocation functions
//==============================================================================
void  HeapInit(uint8* heapBuff, uint32 heapSize, void(*callback)(void));
void* HeapMalloc(uint32 memSize);
BOOL  HeapFree(void*);

//==============================================================================
// Dynamic function
//==============================================================================

//=================================================================================================
// Initialize for dynamic task queue
//
// Input:   none
// Return:  none
//=================================================================================================
void  InitDynamicTask(void);

//=================================================================================================
// Create a dynamic task. Can be called in ISR
//
// Input:   taskId - task serial ID, start from 0
//          taskEntry - task function entry, must be type of (void (*) (void))
// Return:  0x01 - create-task success
//          0xff - create-task failed
//          0x00 - tast already exists
//=================================================================================================
uint8  CreateDynamicTask(uint8 taskId, void *taskEntry);
#define     TASK_CREATE_SUCCESS     0x01
#define     TASK_CREATE_EXIST       0x00
#define     TASK_CREATE_FAILED      0xff

//=================================================================================================
// Kill a dynamic task. CAN NOT be called in ISR
//
// Input:   taskId - task serial ID, start from 0
// Return:  0x01 - kill-task success
//          0xff - kill-task failed
//=================================================================================================
uint8  KillDynamicTask(uint8 taskId);
#define     TASK_KILL_SUCCESS       0x01
#define     TASK_KILL_FAILED        0xff

//=================================================================================================
// Run dynamic task queue
//
// Input:   none
// Return:  none
//=================================================================================================
void  RunDynamicTask(void);


//=================================================================================================
// Comm TX packet processing
//=================================================================================================
typedef struct {
   //comm packet wrapping control
   uint8 pktEof,        //End-Of-Packet tag
         pktSub,        //substitute tag
         pktSd1,        //pktSub+pktSd1 = pktEof
         pktSd2;        //pktSub+pktSd2 = pktSub
   //comm packet TX
   uint8 *pktTxBuff,    //TX packet buffer
         pktTxPtr,      //TX packet offset pointer
         pktTxLen,      //TX packet length
         pktTxChksum;   //TX packet checksum
   //comm packet RX
   uint8 *pktRxBuff,    //RX packet buffer
         pktRxLen,      //RX packet length
         pktRxMax,      //RX packet lmax size
         pktRxChksum;   //RX packet checksum
   unsigned pktRxErr:1; //RX packet error flag
   unsigned pktRxSub:1; //RX packet data substitution flag
} COMM_TXRX_PKT;

void OutPacket_Start(COMM_TXRX_PKT *pktInfo);
void OutPacket_End(COMM_TXRX_PKT *pktInfo, void(*txEn)(void));
void OutPacket_Append(COMM_TXRX_PKT *pktInfo, uint8 datOut);
void OutPacket_String(COMM_TXRX_PKT *pktInfo, uint8 *str, uint8 count);
void OutPacket_Fill(COMM_TXRX_PKT *pktInfo, uint8 dat, uint8 count);
void InPacket_Reset(COMM_TXRX_PKT *pktInfo);
void InPacket_Append(COMM_TXRX_PKT *pktInfo, uint8 dat);
BOOL InPacket_IsError(COMM_TXRX_PKT *pktInfo);

#endif
